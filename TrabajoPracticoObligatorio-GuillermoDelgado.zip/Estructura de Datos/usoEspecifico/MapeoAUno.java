package usoEspecifico;

public class MapeoAUno {
    
}
